export declare const stream: (url: string) => Promise<unknown>;
