export declare function maxBy<T>(arr: T[], fn: (i: T) => number): T | undefined;
