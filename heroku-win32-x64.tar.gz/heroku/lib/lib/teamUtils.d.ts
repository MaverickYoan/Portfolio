export declare const isTeamApp: (owner: string | undefined) => boolean;
export declare const getOwner: (owner: string | undefined) => string | undefined;
export declare const isValidEmail: (email: string) => boolean;
