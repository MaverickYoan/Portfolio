export declare const uuidValidate: (uuid: string) => boolean;
