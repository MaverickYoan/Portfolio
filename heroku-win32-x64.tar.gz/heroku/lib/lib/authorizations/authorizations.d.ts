import * as Heroku from '@heroku-cli/schema';
export declare function display(auth: Heroku.OAuthAuthorization): void;
