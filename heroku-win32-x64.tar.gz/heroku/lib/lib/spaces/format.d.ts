export declare function displayCIDR(cidr: string[] | undefined): string;
export declare function hostStatus(s: string): string;
export declare function peeringStatus(s: string): string;
export declare function displayVPNStatus(s: string | undefined): string | undefined;
