import * as logger from 'debug';
export declare const debug: logger.Debugger;
