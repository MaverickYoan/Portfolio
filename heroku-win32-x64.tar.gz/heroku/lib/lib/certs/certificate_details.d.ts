import { SniEndpoint } from '../types/sni_endpoint';
export declare const displayCertificateDetails: (sniEndpoint: SniEndpoint, message?: string) => void;
