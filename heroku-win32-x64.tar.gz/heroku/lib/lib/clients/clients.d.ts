export declare function validateURL(uri: string): string;
