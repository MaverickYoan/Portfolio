export declare type AppErrors = {
    start_time: string;
    end_time: string;
    step: string;
    data: Record<string, number[]>;
};
