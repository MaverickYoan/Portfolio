export default function getRepo(github: any, name: any): any;
