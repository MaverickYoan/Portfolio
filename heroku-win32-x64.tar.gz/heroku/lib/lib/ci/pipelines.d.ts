import { APIClient } from '@heroku-cli/command';
export declare function disambiguatePipeline(pipelineIDOrName: any, herokuAPI: APIClient): Promise<any>;
export declare function getPipeline(flags: any, herokuAPI: APIClient): Promise<any>;
